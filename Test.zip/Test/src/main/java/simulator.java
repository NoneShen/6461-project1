import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class simulator {
    private JPanel rootpanel;
    private JTextField r2_textField;
    private JTextField mfr_textField;
    private JTextField irr_textField;
    private JTextField mem_textField;
    private JTextField mbr_textField;
    private JTextField textField2;
    private JButton clearButton;
    private JButton haltButton;
    private JButton IPLButton;
    private JButton singleStepButton;
    private JButton runButton;
    private JTextField x3_textField;
    private JTextField iar_textField;
    private JTextField r1_textField;
    private JTextField r3_textField;
    private JTextField x2_textField;
    private JTextField x1_textField;
    private JRadioButton r0RadioButton;
    private JRadioButton r1RadioButton;
    private JRadioButton r2RadioButton;
    private JRadioButton r3RadioButton;
    private JTextField data1_textField;
    private JButton enter_register;
    private JTextField pc_textField;
    private JTextField address_textField;
    private JTextArea resultsTextArea;
    private JTextField r0_textField;
    private JTextField ir_textField;
    private JTextField cc_textField;
    private JTextField mar_textField;
    private JTextField data2_textField;
    private JTextField data3_textField;
    private JButton enter_memory;
    private JButton enter_pc;

    public static String[] memory = new String[2048];

    public final static boolean isBinary(String s) {//判断是否是二进制字符串
        if (s != null && !"".equals(s.trim()))
            return s.matches("^[0-1]*$");
        else
            return false;
    }
    public  void cpu(String instruction){
        if (instruction.length() != 16) {
            resultsTextArea.append("Illegal request, machine fault\r\n");
            //mfr_textField.setText("01");//MFR 应该是二进制数
        }
        else {
            int opcode = Integer.parseInt(instruction.substring(0, 6), 2);
            int ix = Integer.parseInt(instruction.substring(8, 10), 2);
            int r = Integer.parseInt(instruction.substring(6, 8), 2);
            int i = Integer.parseInt(instruction.substring(10, 11), 2);
            int addr = Integer.parseInt(instruction.substring(11, 16), 2);


            calculateEA(i, ix, addr, opcode);

            if (opcode == 1) {
                ldrInstr(r);
            } else if (opcode == 2) {
                strInstr(r);
            } else if (opcode == 3) {
                ldaInstr(r);
            } else if (opcode == 41) {

                ldxInstr(ix);


            } else if (opcode == 42) {
                stxInstr(ix);
            } else {
                machinefault_opcode();
            }
        }

    }
    public int calculateEA(int i,int ix, int addr,int opcode){
        int eff_addr = 0;
        if(opcode==41||opcode==42){
            if(i==1){
                eff_addr = Integer.parseInt(memory[addr], 2);//
            }
            if(i==0){
                eff_addr =addr;
            }
        }
        else {
            if (i == 1) {//改过
                if (ix == 0) {
                    eff_addr = Integer.parseInt(memory[addr], 2);//
                }
                if (ix == 1) {

                    addr=Integer.parseInt(x1_textField.getText(), 2) + addr;
                    if(addr>2047){
                        machinefault_address_beyond();
                    }else if(addr<6){
                        machinefault_reserved_locations();
                    }
                    else {
                        eff_addr = Integer.parseInt(memory[addr], 2);
                    }
                }
                if (ix == 2) {
                    addr=Integer.parseInt(x2_textField.getText(), 2) + addr;
                    if(addr>2047){
                        machinefault_address_beyond();
                    }else if(addr<6){
                        machinefault_reserved_locations();
                    }else {
                        eff_addr = Integer.parseInt(memory[addr], 2);
                    }
                }
                if (ix == 3) {

                    addr=Integer.parseInt(x3_textField.getText(), 2) + addr;
                    if(addr>2047){
                        machinefault_address_beyond();
                    }else if(addr<6){
                        machinefault_reserved_locations();
                    }else {
                        eff_addr = Integer.parseInt(memory[addr], 2);
                    }
                }
            } else if (i == 0) {


                if (ix == 0) {
                    eff_addr = addr;

                }
                if (ix == 1) {

                    eff_addr = addr + Integer.parseInt(x1_textField.getText(), 2);
                }
                if (ix == 2) {
                    eff_addr = addr + Integer.parseInt(x2_textField.getText(), 2);
                }
                if (ix == 3) {
                    eff_addr = addr + Integer.parseInt(x3_textField.getText(), 2);
                }
            }
        }
        if(eff_addr>2047){
            machinefault_address_beyond();
            return 0;
        }else if(addr<6){
            machinefault_reserved_locations();
            return 0;
        }
        else {
            iar_textField.setText(Integer.toBinaryString(eff_addr));//把EA存入IAR

            return eff_addr;
        }

    }
    public String fetch(String address){//fetch data by address from CPU

        mar_textField.setText(address);
        int decimal_address=Integer.parseInt(address,2);
        if (decimal_address>2047){
            machinefault_address_beyond();
            return "0";
        }else if(decimal_address<6){
            machinefault_reserved_locations();
            return "0";
        }else {
            mem_textField.setText(memory[decimal_address]);
            mbr_textField.setText(memory[decimal_address]);

            return memory[decimal_address];
        }

    }





    public simulator() {


//构建ratio组，才能单选

            ButtonGroup group = new ButtonGroup();
            group.add(this.r0RadioButton);
            group.add(this.r1RadioButton);
            group.add(this.r2RadioButton);
            group.add(this.r3RadioButton);


        clearButton.addActionListener(new ActionListener() {// 清空所有的text
            @Override
            public void actionPerformed(ActionEvent e) {
                r0_textField.setText("");
                r1_textField.setText("");
                r2_textField.setText("");
                r3_textField.setText("");
                x1_textField.setText("");
                x2_textField.setText("");
                x3_textField.setText("");
                pc_textField.setText("");
                ir_textField.setText("");
                mar_textField.setText("");
                mbr_textField.setText("");
                mfr_textField.setText("");
                irr_textField.setText("");
                iar_textField.setText("");
                data1_textField.setText("");
                data2_textField.setText("");
                data3_textField.setText("");
                address_textField.setText("");
                cc_textField.setText("");

            }
        });
        enter_register.addActionListener(new ActionListener() {//machine fault:can only be binary number
            @Override
            public void actionPerformed(ActionEvent e) {
                java.lang.String input_data=data1_textField.getText();
                if(isBinary(input_data)&&input_data.length()<=16){
                    if(r0RadioButton.isSelected()){
                        r0_textField.setText(input_data);
                        resultsTextArea.append("Enter data " + input_data+" into R0"+"\r\n");//display
                    }
                    else if(r1RadioButton.isSelected()){
                        r1_textField.setText(input_data);
                        resultsTextArea.append("Enter data " + input_data+" into R1"+"\r\n");//display
                    }
                    else if(r2RadioButton.isSelected()){
                        r2_textField.setText(input_data);
                        resultsTextArea.append("Enter data " + input_data+" into R2"+"\r\n");//display
                    }
                    else if(r3RadioButton.isSelected()){
                        r3_textField.setText(input_data);
                        resultsTextArea.append("Enter data " + input_data+" into R3"+"\r\n");//display
                    }
                }
                else if(!isBinary(input_data)){
                    resultsTextArea.append("Error, your input is not binary number!"+"\r\n");
                }
                else{
                    resultsTextArea.append("Error, the length of your input is not legal!"+"\r\n");
                }





            }
        });
        enter_memory.addActionListener(new ActionListener() {//machine fault:can only be binary number
            @Override
            public void actionPerformed(ActionEvent e) {
                java.lang.String input_data=data2_textField.getText();
                java.lang.String input_address=address_textField.getText();
                int decimal_address=Integer.parseInt(input_address, 2);
                if(isBinary(input_data)&&isBinary(input_address)&&decimal_address<=2047&&decimal_address>=6) {//合法
                    resultsTextArea.append("Enter data " + input_data+" into Memory["+decimal_address+"]"+"\r\n");//display

                    memory[decimal_address]=input_data;

                }
                else if(!isBinary(data2_textField.getText())||!isBinary(address_textField.getText())){//不是数字
                    resultsTextArea.append("Error, your input is not binary number!"+"\r\n");
                }

                else{//长度不合法
                    resultsTextArea.append("Error, the value of the address of you input is not legal!"+"\r\n");

                }


            }
        });
        enter_pc.addActionListener(new ActionListener() {//machine fault:can only be binary number
            @Override
            public void actionPerformed(ActionEvent e) {
                java.lang.String input_data=data3_textField.getText();
                if(isBinary(input_data)&&Integer.parseInt(input_data,2)<=2047&&Integer.parseInt(input_data,2)>=7) {
                    pc_textField.setText(input_data);
                    resultsTextArea.append("Enter data " +input_data+"into PC"+"\r\n");
                }
                else if(!isBinary(input_data)){
                    resultsTextArea.append("Error, your input is not binary number!"+"\r\n");
                }
                else{
                    resultsTextArea.append("Error, the value of your input is more than 2047 or less than 7!"+"\r\n");

                }

            }
        });


        singleStepButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mar_textField.setText(pc_textField.getText());

                String instruction=memory[Integer.parseInt(mar_textField.getText(),2)];
                mem_textField.setText(instruction);
                mbr_textField.setText(instruction);
                cpu(instruction);


            }
        });
        mar_textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                mem_textField.setText(memory[Integer.parseInt(mar_textField.getText(),2)]);//在mar里面随便输入数据，按回车，可以在mem中看到对应地址的内存
            }
        });
        IPLButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                readFileByLines("ROM.txt");

            }
        });
        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i=8;
                while(i<14){
                    String instruction=memory[i];
                    mem_textField.setText(instruction);
                    mbr_textField.setText(instruction);
                    cpu(instruction);
                    i++;
                }

            }
        });
    }

    public  void readFileByLines(String fileName) {
        File file = new File(fileName);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                String address=(tempString.substring(17,22));
                int decimal_address=Integer.parseInt(address,2);
                String instruction=tempString.substring(0,16);
                // 显示行号
                if(line==1){
                    pc_textField.setText(address);
                }

                memory[decimal_address]=instruction;
                resultsTextArea.append("Store "+instruction+ "to memory["+decimal_address+"]"+"\r\n");
                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
    }

   public void ldrInstr(int r){

        irr_textField.setText(fetch(iar_textField.getText()));
        String data=irr_textField.getText();
        int decimal_data=Integer.parseInt(data,2);
        if(r==0){
            r0_textField.setText(data);
            resultsTextArea.append("Load R0 from memory["+decimal_data+"]"+"\r\n");

        }else if(r==1){
            r1_textField.setText(data);
            resultsTextArea.append("Load R1 from memory["+decimal_data+"]"+"\r\n");
        }else if(r==2){
            r2_textField.setText(data);
            resultsTextArea.append("Load R2 from memory["+decimal_data+"]"+"\r\n");
        }else if(r==3){
            r3_textField.setText(data);
            resultsTextArea.append("Load R3 from memory["+decimal_data+"]"+"\r\n");
        }

   }
   public void strInstr(int r){
        int mem_address=Integer.parseInt(iar_textField.getText(),2);
        if(r==0){
       memory[mem_address]=r0_textField.getText();
            resultsTextArea.append("Store R0 to memory["+mem_address+"]"+"\r\n");
   }else if(r==1){
            memory[mem_address]=r1_textField.getText();
            resultsTextArea.append("Store R1 to memory["+mem_address+"]"+"\r\n");
    }else if(r==2){
            memory[mem_address]=r2_textField.getText();
            resultsTextArea.append("Store R2 to memory["+mem_address+"]"+"\r\n");
    }else if(r==3){
            memory[mem_address]=r3_textField.getText();
            resultsTextArea.append("Store R3 to memory["+mem_address+"]"+"\r\n");
    }

}

public void ldaInstr(int r){
        String address=iar_textField.getText();
    if(r==0){
        r0_textField.setText(address);
        resultsTextArea.append("Load R0 with "+address+"\r\n");

    }else if(r==1){
        r1_textField.setText(address);
        resultsTextArea.append("Load R1 with "+address+"\r\n");
    }else if(r==2){
        r2_textField.setText(address);
        resultsTextArea.append("Load R2 with "+address+"\r\n");
    }else if(r==3){
        r3_textField.setText(address);
        resultsTextArea.append("Load R3 with "+address+"\r\n");
    }
    }

    public void ldxInstr(int ix){
        irr_textField.setText(fetch(iar_textField.getText()));
        String data=irr_textField.getText();
        int decimal_data=Integer.parseInt(data,2);
        if(ix==0){
            //machine fault  ix不应该是0

        }else if(ix==1){
            x1_textField.setText(data);
            resultsTextArea.append("Load X1 from memory["+decimal_data+"]"+"\r\n");
        }else if(ix==2){
            x2_textField.setText(data);
            resultsTextArea.append("Load X2 from memory["+decimal_data+"]"+"\r\n");
        }else if(ix==3){
            x3_textField.setText(data);
            resultsTextArea.append("Load X3 from memory["+decimal_data+"]"+"\r\n");
        }

    }
    public void stxInstr(int ix){
        int mem_address=Integer.parseInt(iar_textField.getText(),2);
        if(ix==0){
            //machine fault  ix不应该是0
        }else if(ix==1){
            memory[mem_address]=x1_textField.getText();
            resultsTextArea.append("Store X1 to memory["+mem_address+"]"+"\r\n");
        }else if(ix==2){
            memory[mem_address]=x2_textField.getText();
            resultsTextArea.append("Store X2 to memory["+mem_address+"]"+"\r\n");
        }else if(ix==3){
            memory[mem_address]=x3_textField.getText();
            resultsTextArea.append("Store X3 to memory["+mem_address+"]"+"\r\n");
        }

    }
    public void machinefault_opcode(){
        resultsTextArea.append("Machine fault: Illegal Operation Code\r\n");
        resultsTextArea.append("MFR set to 0100\r\n");
        mfr_textField.setText("0100");
        resultsTextArea.append("Store PC for Machine Fault to Memory[4]"+"\r\n");
        memory[4]=pc_textField.getText();

    }
    public void machinefault_address_beyond(){
        resultsTextArea.append("Machine fault: Illegal Memory Address beyond 2048 \r\n");
        resultsTextArea.append("MFR set to 1000\r\n");
        mfr_textField.setText("1000");
        resultsTextArea.append("Store PC for Machine Fault to Memory[4]"+"\r\n");
        memory[4]=pc_textField.getText();

    }
    public void machinefault_reserved_locations(){
        resultsTextArea.append("Machine fault: Illegal Memory Address to Reserved Locations \r\n");
        resultsTextArea.append("MFR set to 0001\r\n");
        mfr_textField.setText("0001");
        resultsTextArea.append("Store PC for Machine Fault to Memory[4]"+"\r\n");
        memory[4]=pc_textField.getText();
    }






    public static void main(String[] args) {
        JFrame frame = new JFrame("simulator");
        frame.setContentPane(new simulator().rootpanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

